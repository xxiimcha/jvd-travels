

<?php $__env->startSection('content'); ?>
<section class="inner-banner-wrap">
    <div class="inner-baner-container" style="background-image: url('<?php echo e(asset('assets/customer/images/inner-banner.jpg')); ?>');">
        <div class="container">
            <div class="inner-banner-content">
                <h1 class="inner-title">Customer Login</h1>
            </div>
        </div>
    </div>
    <div class="inner-shape"></div>
</section>

<section class="contact-section pt-5 pb-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 bg-white p-5 shadow">
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>

                <?php if(session('otp_required')): ?>
                    <form method="POST" action="<?php echo e(route('customer.verify.otp')); ?>" class="row">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 mb-3">
                            <label class="form-label">Enter OTP sent to your email</label>
                            <input type="text" name="otp" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="button-primary w-100">Verify OTP</button>
                        </div>
                    </form>
                <?php else: ?>
                    <form method="POST" action="<?php echo e(route('customer.login')); ?>" class="row">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
                        </div>
                        <div class="col-12 mb-4">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="button-primary w-100">Login</button>
                        </div>
                        <div class="col-12 text-center mt-3">
                            <a href="<?php echo e(route('customer.register')); ?>">Don’t have an account? Register now</a>
                        </div>
                    </form>
                <?php endif; ?>

                <?php if($errors->has('error')): ?>
                    <div class="alert alert-danger mt-3">
                        <?php echo e($errors->first('error')); ?>

                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/customer/auth/login.blade.php ENDPATH**/ ?>