

<?php $__env->startSection('title', 'All Tours'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow card-primary card-outline">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">All Tours</h3>
        <a href="<?php echo e(route('admin.tours.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus-circle"></i> Add New Tour
        </a>
    </div>

    <div class="card-body table-responsive">
        <?php if($tours->isEmpty()): ?>
            <div class="alert alert-info">No tours found.</div>
        <?php else: ?>
        <table class="table table-bordered table-hover">
            <thead class="thead-light">
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Tour Type</th>
                    <th>Duration</th>
                    <th>Price (₱)</th>
                    <th>Capacity</th>
                    <th>Schedules</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $first = $group->first();
                ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($first->title); ?></td>
                    <td><?php echo e($first->tour_type); ?></td>
                    <td><?php echo e($first->duration_days); ?>D/<?php echo e($first->duration_nights); ?>N</td>
                    <td>₱<?php echo e(number_format($first->price, 2)); ?></td>
                    <td><?php echo e($first->capacity); ?></td>
                    <td>
                        <ul class="mb-0">
                            <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e(\Carbon\Carbon::parse($schedule->schedule_date)->format('F j, Y')); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.tours.show', $first->id)); ?>" class="btn btn-sm btn-info">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="#" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                        <form action="#" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this tour schedule group?')">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/admin/tours/index.blade.php ENDPATH**/ ?>