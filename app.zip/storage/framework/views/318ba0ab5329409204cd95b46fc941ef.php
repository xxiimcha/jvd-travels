<script src="<?php echo e(asset('assets/customer/js/jquery.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
<!-- Bootstrap 5 Bundle JS (includes Popper.js) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="<?php echo e(asset('assets/customer/vendors/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customer/vendors/countdown-date-loop-counter/loopcounter.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customer/js/jquery.counterup.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customer/vendors/modal-video/jquery-modal-video.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customer/vendors/masonry/masonry.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customer/vendors/lightbox/dist/js/lightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customer/vendors/slick/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customer/js/jquery.slicknav.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customer/js/custom.min.js')); ?>"></script>
<?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/partials/customer/scripts.blade.php ENDPATH**/ ?>