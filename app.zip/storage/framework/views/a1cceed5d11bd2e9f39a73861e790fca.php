

<?php $__env->startSection('title', 'Available Tours'); ?>

<?php $__env->startSection('content'); ?>
<section class="inner-banner-wrap">
    <div class="inner-baner-container" style="background-image: url('<?php echo e(asset('assets/images/inner-banner.jpg')); ?>');">
        <div class="container">
            <div class="inner-banner-content">
                <h1 class="inner-title">Available Tours</h1>
            </div>
        </div>
    </div>
</section>

<section class="package-section pt-5 pb-5">
    <div class="container">
        <div class="package-inner">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="package-wrap">
                            <figure class="feature-image">
                                <a href="<?php echo e(route('customer.tours.show', $tour->api_tour_id)); ?>">
                                    <img src="<?php echo e(asset('storage/' . $tour->brochure)); ?>" alt="Tour Image" onerror="this.src='<?php echo e(asset('assets/images/default-tour.jpg')); ?>'">                                </a>
                            </figure>
                            <div class="package-price">
                                <h6>
                                    <span>Starts at ₱<?php echo e(number_format($tour->min_price, 2)); ?></span>
                                </h6>
                            </div>
                            <div class="package-content-wrap">
                                <div class="package-meta text-center">
                                    <ul>
                                        <li><i class="fas fa-users"></i> <?php echo e($tour->tour_type); ?></li>
                                        <li><i class="fas fa-clock"></i> <?php echo e($tour->duration_days); ?> Days / <?php echo e($tour->duration_nights); ?> Nights</li>
                                    </ul>
                                </div>
                                <div class="package-content">
                                    <h3>
                                        <a href="<?php echo e(route('customer.tours.show', $tour->api_tour_id)); ?>"><?php echo e($tour->title); ?></a>
                                    </h3>
                                    <p><?php echo $tour->description; ?></p>
                                    <div class="btn-wrap mt-3">
                                        <a href="<?php echo e(route('customer.tours.show', $tour->api_tour_id)); ?>" class="button-text width-6">View Schedules <i class="fas fa-arrow-right"></i></a>
                                        <a href="#" class="button-text width-6">Wish List<i class="far fa-heart"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center">
                        <p class="text-muted">No tours available at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/customer/tours/index.blade.php ENDPATH**/ ?>