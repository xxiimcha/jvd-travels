<?php $__env->startSection('title', 'Available Hotels'); ?>

<?php $__env->startSection('content'); ?>
<section class="inner-banner-wrap">
    <div class="inner-baner-container" style="background-image: url('<?php echo e(asset('assets/images/inner-banner.jpg')); ?>');">
        <div class="container">
            <div class="inner-banner-content">
                <h1 class="inner-title">Available Hotels</h1>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('home.search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<section class="package-section pt-5 pb-5">
    <div class="container">
        <div class="package-inner">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $roomTypes = json_decode($hotel->room_type_pricing ?? '[]', true);
                        $imagePath = asset('storage/hotel_images/' . $hotel->id . '.jpg');
                    ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="package-wrap">
                            <figure class="feature-image">
                                <a href="#">
                                    <img src="<?php echo e($imagePath); ?>" alt="Hotel Image" onerror="this.src='<?php echo e(asset('assets/images/default-hotel.jpg')); ?>'">
                                </a>
                            </figure>
                            <div class="package-price">
                            <h6>
                                <span>
                                    From ₱
                                    <?php echo e(isset($roomTypes[0]['price']) ? number_format($roomTypes[0]['price']) : 'N/A'); ?>

                                </span>
                            </h6>
                            </div>
                            <div class="package-content-wrap">
                                <div class="package-meta text-center">
                                    <ul>
                                        <li><i class="fas fa-map-marker-alt"></i> <?php echo e($hotel->location); ?></li>
                                    </ul>
                                </div>
                                <div class="package-content">
                                    <h3>
                                        <a href="<?php echo e(route('customer.hotels.show', $hotel->id)); ?>"><?php echo e($hotel->hotel_name); ?></a>
                                    </h3>
                                    <p><strong>Address:</strong> <?php echo e($hotel->address); ?></p>
                                    <?php if(!empty($roomTypes)): ?>
                                        <ul class="ps-3">
                                            <?php $__currentLoopData = $roomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($room['type']); ?> - ₱<?php echo e(number_format($room['price'], 2)); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <p class="text-muted">No room types available</p>
                                    <?php endif; ?>
                                    <div class="btn-wrap mt-3">
                                        <a href="#" class="button-text width-6">Book Now<i class="fas fa-arrow-right"></i></a>
                                        <a href="#" class="button-text width-6">Wish List<i class="far fa-heart"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center">
                        <p class="text-muted">No hotels available at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/customer/hotels/index.blade.php ENDPATH**/ ?>