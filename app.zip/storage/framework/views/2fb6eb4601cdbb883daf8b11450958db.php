<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" type="image/png" href="<?php echo e(asset('assets/logo.png')); ?>">

<!-- CSS Files -->
<link rel="stylesheet" href="<?php echo e(asset('assets/customer/vendors/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/customer/vendors/fontawesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/customer/vendors/jquery-ui/jquery-ui.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/customer/vendors/modal-video/modal-video.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/customer/vendors/lightbox/dist/css/lightbox.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/customer/vendors/slick/slick.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/customer/vendors/slick/slick-theme.css')); ?>">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&family=Raleway:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/customer/style.css')); ?>">

<title>JVD Travel & Tours</title>
<?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/partials/customer/head.blade.php ENDPATH**/ ?>