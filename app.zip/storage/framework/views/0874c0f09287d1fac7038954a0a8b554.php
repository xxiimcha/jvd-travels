<div class="row">
    <?php $__currentLoopData = $popularPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6">
            <div class="package-wrap">
                <figure class="feature-image">
                    <a href="#">
                        <img src="<?php echo e(asset('storage/' . $package->brochure)); ?>" alt="Tour Image" onerror="this.src='<?php echo e(asset('assets/images/default-tour.jpg')); ?>'">
                    </a>
                </figure>
                <div class="package-price">
                    <h6>
                        <span>₱<?php echo e(number_format($package->price, 2)); ?> </span> / per person
                    </h6>
                </div>
                <div class="package-content-wrap">
                    <div class="package-meta text-center">
                        <ul>
                            <li><i class="far fa-clock"></i> <?php echo e($package->duration_days); ?>D/<?php echo e($package->duration_nights); ?>N</li>
                            <li><i class="fas fa-user-friends"></i> People: <?php echo e($package->capacity); ?></li>
                            <li><i class="fas fa-map-marker-alt"></i> <?php echo e($package->title); ?></li>
                        </ul>
                    </div>
                    <div class="package-content">
                        <h3>
                            <a href="#"><?php echo e($package->title); ?></a>
                        </h3>
                        <p><?php echo \Illuminate\Support\Str::limit(strip_tags($package->description), 100); ?></p>
                        <div class="btn-wrap">
                            <a href="<?php echo e(route('customer.tours.show', $package->api_tour_id)); ?>" class="button-text width-6">Book Now <i class="fas fa-arrow-right"></i></a>
                            <a href="#" class="button-text width-6">Wish List <i class="far fa-heart"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/home/packages.blade.php ENDPATH**/ ?>