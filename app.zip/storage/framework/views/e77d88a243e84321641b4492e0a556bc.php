

<?php $__env->startSection('title', 'Tour Bookings'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow card-primary card-outline">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">Tour Bookings</h3>
    </div>

    <div class="card-body table-responsive">
        <?php if($bookings->isEmpty()): ?>
            <div class="alert alert-info">No tour bookings found.</div>
        <?php else: ?>
        <table class="table table-bordered table-hover">
            <thead class="thead-light">
                <tr>
                    <th>#</th>
                    <th>Customer</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Schedule</th>
                    <th>Pax</th>
                    <th>Total Price</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($booking->full_name); ?></td>
                    <td><?php echo e($booking->email); ?></td>
                    <td><?php echo e($booking->contact); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($booking->schedule->schedule_date)->format('F j, Y')); ?></td>
                    <td><?php echo e($booking->pax_count ?? 'N/A'); ?></td>
                    <td>₱<?php echo e(number_format($booking->total_price, 2)); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($booking->status == 'pending' ? 'warning' : ($booking->status == 'approved' ? 'success' : 'danger')); ?>">
                            <?php echo e(ucfirst($booking->status)); ?>

                        </span>
                    </td>
                    <td>
                        <?php if($booking->status == 'pending'): ?>
                        <form method="POST" action="<?php echo e(route('admin.tours.bookings.update', $booking->id)); ?>" style="display:inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="status" value="approved">
                            <button type="submit" class="btn btn-sm btn-success">Approve</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('admin.tours.bookings.update', $booking->id)); ?>" style="display:inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="status" value="rejected">
                            <button type="submit" class="btn btn-sm btn-danger">Reject</button>
                        </form>
                        <?php else: ?>
                            <button class="btn btn-sm btn-secondary" disabled>No Action</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/admin/tours/bookings.blade.php ENDPATH**/ ?>