<?php $__env->startSection('title', $hotel->hotel_name); ?>

<?php $__env->startSection('content'); ?>
<section class="inner-banner-wrap">
    <div class="inner-baner-container" style="background-image: url('<?php echo e(asset('assets/images/inner-banner.jpg')); ?>');">
        <div class="container">
            <div class="inner-banner-content">
                <h1 class="inner-title"><?php echo e($hotel->hotel_name); ?></h1>
            </div>
        </div>
    </div>
</section>

<div class="single-tour-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="single-tour-inner">
                    <figure class="feature-image mb-4">
                        <img src="<?php echo e($imagePath); ?>" alt="Hotel Image" onerror="this.src='<?php echo e(asset('assets/images/default-hotel.jpg')); ?>'">
                    </figure>
                    <div class="tab-container mt-4">
                        <ul class="nav nav-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" data-bs-toggle="tab" href="#overview">Overview</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="tab" href="#rooms">Room Types</a>
                            </li>
                        </ul>
                        <div class="tab-content pt-3">
                            <div class="tab-pane fade show active" id="overview">
                                <table class="table table-bordered">
                                    <tr><th>Hotel Name</th><td><?php echo e($hotel->hotel_name); ?></td></tr>
                                    <tr><th>Location</th><td><?php echo e($hotel->location); ?></td></tr>
                                    <tr><th>Address</th><td><?php echo e($hotel->address); ?></td></tr>
                                </table>
                            </div>
                            <div class="tab-pane fade" id="rooms">
                                <?php if(!empty($roomTypes)): ?>
                                    <div class="row">
                                        <?php $__currentLoopData = $roomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6 mb-3">
                                                <div class="card h-100 shadow-sm">
                                                    <div class="card-body d-flex flex-column justify-content-between">
                                                        <div>
                                                            <h5 class="card-title"><?php echo e($room['type']); ?></h5>
                                                            <p class="card-text text-muted">Price: ₱<?php echo e(number_format($room['price'], 2)); ?></p>
                                                        </div>
                                                        <a href="<?php echo e(route('customer.hotels.book', ['id' => $hotel->id, 'room' => $room['type']])); ?>" class="btn btn-primary mt-3 w-100">
                                                            Book Now
                                                        </a>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted">No room types available.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/customer/hotels/show.blade.php ENDPATH**/ ?>