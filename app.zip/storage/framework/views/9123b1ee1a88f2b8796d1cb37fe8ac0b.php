

<?php $__env->startSection('content'); ?>
<section class="inner-banner-wrap">
    <div class="inner-baner-container" style="background-image: url('<?php echo e(asset('assets/customer/images/inner-banner.jpg')); ?>');">
        <div class="container">
            <div class="inner-banner-content">
                <h1 class="inner-title">Create Account</h1>
            </div>
        </div>
    </div>
</section>

<section class="contact-section pt-5 pb-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 bg-white p-5 shadow">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('customer.register.submit')); ?>" class="row">
                    <?php echo csrf_field(); ?>
                    <div class="col-12 mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="col-12 mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="col-12 mb-4">
                        <label class="form-label">Confirm Password</label>
                        <input type="password" name="password_confirmation" class="form-control" required>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="button-primary w-100">Register</button>
                    </div>
                    <div class="col-12 text-center mt-3">
                        <a href="<?php echo e(route('customer.login')); ?>">Already have an account? Login</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/customer/auth/register.blade.php ENDPATH**/ ?>