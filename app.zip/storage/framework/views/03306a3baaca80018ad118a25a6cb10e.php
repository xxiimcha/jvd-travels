<!doctype html>
<html lang="en">
<head>
    <?php echo $__env->make('partials.customer.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body class="home">

    <div id="page" class="full-page">
        <?php echo $__env->make('partials.customer.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

         <main id="content" class="site-main">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <?php echo $__env->make('partials.customer.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    <?php echo $__env->make('partials.customer.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/layouts/customer.blade.php ENDPATH**/ ?>