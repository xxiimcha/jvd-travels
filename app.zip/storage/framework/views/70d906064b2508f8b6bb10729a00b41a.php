

<?php $__env->startSection('title', 'Transport Bookings'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow card-outline card-primary">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title mb-0">Vehicle Booking Records</h3>
    </div>

    <div class="card-body table-responsive">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered table-hover align-middle">
            <thead class="thead-light">
                <tr>
                    <th>#</th>
                    <th>Customer Name</th>
                    <th>Email</th>
                    <th>Pickup & Return</th>
                    <th>Origin & Destination</th>
                    <th>Vehicles</th>
                    <th>Total Price</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($booking->full_name); ?></td>
                    <td><?php echo e($booking->email); ?></td>
                    <td>
                        <strong>Pickup:</strong> <?php echo e(\Carbon\Carbon::parse($booking->pickup_date)->format('M d, Y h:i A')); ?><br>
                        <strong>Return:</strong> <?php echo e(\Carbon\Carbon::parse($booking->return_date)->format('M d, Y h:i A')); ?>

                    </td>
                    <td><?php echo e($booking->origin); ?> → <?php echo e($booking->destination); ?></td>
                    <td>
                        <?php
                            $ids = is_array(json_decode($booking->vehicle_id, true)) ? json_decode($booking->vehicle_id, true) : [$booking->vehicle_id];
                        ?>
                        <?php $__currentLoopData = $ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($vehicles[$vid])): ?>
                                <span class="badge bg-info text-dark mb-1">
                                    <?php echo e($vehicles[$vid]['model']); ?> <small>(<?php echo e($vehicles[$vid]['manufacturer']); ?>)</small>
                                </span>
                            <?php else: ?>
                                <span class="badge bg-secondary mb-1">ID: <?php echo e($vid); ?></span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>₱<?php echo e(number_format($booking->total_price, 2)); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($booking->status === 'pending' ? 'warning' : ($booking->status === 'approved' ? 'success' : 'secondary')); ?>">
                            <?php echo e(ucfirst($booking->status)); ?>

                        </span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center text-muted">No bookings found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/admin/transport/index.blade.php ENDPATH**/ ?>