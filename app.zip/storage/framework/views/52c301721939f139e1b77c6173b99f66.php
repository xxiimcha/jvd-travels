<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="icon" type="image/png" href="<?php echo e(asset('assets/logo.png')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/all.min.css')); ?>">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Raleway:wght@400;600;700&display=swap">
      <link rel="stylesheet" href="<?php echo e(asset('assets/admin/style.css')); ?>">
      <title>Admin Panel - JVD Travel and Tours</title>
      <?php echo $__env->yieldPushContent('styles'); ?>
   </head>
   <body>
      <div id="container-wrapper">
         <!-- Dashboard Container -->
         <div id="dashboard" class="dashboard-container">

            
            <?php echo $__env->make('partials.admin.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <?php echo $__env->make('partials.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <div class="db-info-wrap">
               <?php echo $__env->yieldContent('content'); ?>
            </div>

            
            <div class="copyrights text-center py-3">
               Copyright © <?php echo e(now()->year); ?> JVD Travel and Tours. All rights reserved.
            </div>
         </div>
      </div>

      <script src="<?php echo e(asset('assets/admin/js/jquery-3.2.1.min.js')); ?>"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
      <script src="<?php echo e(asset('assets/admin/js/bootstrap.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/admin/js/canvasjs.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/admin/js/chart.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/admin/js/counterup.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/admin/js/jquery.slicknav.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/admin/js/dashboard-custom.js')); ?>"></script>
      <?php echo $__env->yieldPushContent('scripts'); ?>
   </body>
</html>
<?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/layouts/admin.blade.php ENDPATH**/ ?>