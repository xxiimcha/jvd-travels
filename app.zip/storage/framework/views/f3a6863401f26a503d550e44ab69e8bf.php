<?php $__env->startSection('title', $vehicle['model'] . ' - ' . $vehicle['manufacturer']); ?>

<?php $__env->startSection('content'); ?>
<section class="inner-banner-wrap">
    <div class="inner-baner-container" style="background-image: url('<?php echo e(asset('assets/images/inner-banner.jpg')); ?>');">
        <div class="container">
            <div class="inner-banner-content">
                <h1 class="inner-title"><?php echo e($vehicle['model']); ?> - <?php echo e($vehicle['manufacturer']); ?></h1>
            </div>
        </div>
    </div>
</section>

<div class="single-tour-section">
    <div class="container">
        <div class="row">
            <!-- Left Section -->
            <div class="col-lg-8">
                <div class="single-tour-inner">
                    <figure class="feature-image">
                        <img src="https://logistic2.easetravelandtours.com/storage/<?php echo e($vehicle['image_path']); ?>" alt="Vehicle Image" onerror="this.src='<?php echo e(asset('assets/images/default-hotel.jpg')); ?>'">
                    </figure>

                    <div class="tab-container mt-4">
                        <ul class="nav nav-tabs" id="vehicleTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="overview-tab" data-toggle="tab" href="#overview" role="tab">Overview</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="gallery-tab" data-toggle="tab" href="#gallery" role="tab">Gallery</a>
                            </li>
                        </ul>
                        <div class="tab-content pt-3" id="vehicleTabContent">
                            <div class="tab-pane fade show active" id="overview" role="tabpanel">
                                <div class="overview-content">
                                    <p><?php echo $vehicle['remarks'] ?? 'No description available for this vehicle.'; ?></p>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="gallery" role="tabpanel">
                                <?php if(!empty($vehicle['image_path'])): ?>
                                <div class="single-tour-gallery mt-3">
                                    <figure class="feature-image">
                                        <img src="https://logistic2.easetravelandtours.com/storage/<?php echo e($vehicle['image_path']); ?>" alt="Vehicle Gallery Image">
                                    </figure>
                                </div>
                                <?php else: ?>
                                <p class="text-muted">No gallery image available.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Sidebar -->
            <div class="col-lg-4">
                <div class="sidebar">
                    <?php if(!empty($vehicle['purchase_price'])): ?>
                    <div class="package-price mb-3">
                        <h5 class="price">
                            <span>₱<?php echo e(number_format($vehicle['purchase_price'], 2)); ?></span> / full rental
                        </h5>
                    </div>
                    <?php endif; ?>

                    <div class="widget-bg p-3 shadow-sm mb-3">
                        <h4 class="bg-title mb-3">Vehicle Details</h4>
                        <table class="table table-bordered table-striped mb-0">
                            <tbody>
                                <tr><th>Type</th><td><?php echo e($vehicle['vehicle_type']); ?></td></tr>
                                <tr><th>Manufacturer</th><td><?php echo e($vehicle['manufacturer']); ?></td></tr>
                                <tr><th>Model</th><td><?php echo e($vehicle['model']); ?></td></tr>
                                <tr><th>Year</th><td><?php echo e($vehicle['year_of_manufacture']); ?></td></tr>
                                <tr><th>Fuel</th><td><?php echo e($vehicle['fuel_type']); ?></td></tr>
                                <tr><th>Capacity</th><td><?php echo e($vehicle['capacity']); ?> persons</td></tr>
                                <tr><th>Color</th><td><?php echo e($vehicle['color']); ?></td></tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="text-center">
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/vehicles/book/' . $vehicle['id'])); ?>" class="button-primary w-100">
                                Book Now
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('customer.login')); ?>" class="button-primary w-100">
                                Book Now
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- End Sidebar -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Commissions\jvd-travel-tours\resources\views/customer/vehicles/show.blade.php ENDPATH**/ ?>