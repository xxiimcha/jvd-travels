<h2>Your OTP Code</h2>
<p>Please use the following OTP to complete your login:</p>
<h1>{{ $otp }}</h1>
<p>This code is valid for one-time use only.</p>