<section class="callback-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="callback-img" style="background-image: url('{{ asset('assets/customer/images/img8.jpg') }}');">
                    <div class="video-button">
                        <a href="#"><i class="fas fa-play"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <h5>CALLBACK FOR MORE</h5>
                <h2>GO TRAVEL. DISCOVER. REMEMBER US!!</h2>
                <p>Our 24/7 emergency phone services are here for you. Call: 123-456-7890</p>
            </div>
        </div>
    </div>
</section>
