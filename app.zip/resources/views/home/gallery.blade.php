<section class="best-section">
    <div class="container">
        <div class="section-heading text-center">
            <h5 class="dash-style">OUR TOUR GALLERY</h5>
            <h2>BEST TRAVELER'S SHARED PHOTOS</h2>
        </div>
        <div class="row">
            <div class="col-md-4"><img src="{{ asset('assets/customer/images/img12.jpg') }}" alt=""></div>
            <div class="col-md-4"><img src="{{ asset('assets/customer/images/img13.jpg') }}" alt=""></div>
            <div class="col-md-4"><img src="{{ asset('assets/customer/images/img14.jpg') }}" alt=""></div>
        </div>
    </div>
</section>
