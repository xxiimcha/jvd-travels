<section class="blog-section">
    <div class="container">
        <div class="section-heading text-center">
            <h5 class="dash-style">FROM OUR BLOG</h5>
            <h2>OUR RECENT POSTS</h2>
        </div>
        <div class="row">
            <div class="col-md-4"><img src="{{ asset('assets/customer/images/img17.jpg') }}" alt=""><p>Life is a journey</p></div>
            <div class="col-md-4"><img src="{{ asset('assets/customer/images/img18.jpg') }}" alt=""><p>Leave only footprints</p></div>
            <div class="col-md-4"><img src="{{ asset('assets/customer/images/img19.jpg') }}" alt=""><p>New friends & stories</p></div>
        </div>
    </div>
</section>
