<section class="activity-section">
    <div class="container">
        <div class="section-heading text-center">
            <h5 class="dash-style">TRAVEL BY ACTIVITY</h5>
            <h2>ADVENTURE & ACTIVITY</h2>
        </div>
        <div class="row text-center">
            <div class="col-md-2"><p>Adventure</p></div>
            <div class="col-md-2"><p>Trekking</p></div>
            <div class="col-md-2"><p>Camp Fire</p></div>
            <div class="col-md-2"><p>Off Road</p></div>
            <div class="col-md-2"><p>Camping</p></div>
            <div class="col-md-2"><p>Exploring</p></div>
        </div>
    </div>
</section>
