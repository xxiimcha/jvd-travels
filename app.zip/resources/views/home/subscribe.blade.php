<section class="subscribe-section" style="background-image: url('{{ asset('assets/customer/images/img16.jpg') }}');">
    <div class="container">
        <div class="section-heading section-heading-white">
            <h2>HOLIDAY SPECIAL 25% OFF!</h2>
            <form class="newsletter-form">
                <input type="email" name="s" placeholder="Your Email Address">
                <input type="submit" name="signup" value="SIGN UP NOW!">
            </form>
        </div>
    </div>
</section>
