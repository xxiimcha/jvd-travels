<section class="contact-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6"><img src="{{ asset('assets/customer/images/img24.jpg') }}" alt=""></div>
            <div class="col-md-6">
                <h3>Let's Join Us for More Updates!</h3>
                <p>Email: support@gmail.com<br>Phone: +01 (977) 2599 12<br>Address: 3146 Koontz, California</p>
                <a href="#" class="button-primary">LEARN MORE</a>
            </div>
        </div>
    </div>
</section>
