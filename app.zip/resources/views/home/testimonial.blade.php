<section class="testimonial-section" style="background-image: url('{{ asset('assets/customer/images/img23.jpg') }}');">
    <div class="container text-center">
        <h2>What Our Clients Say</h2>
        <p>"Best travel service ever! Highly recommend."</p>
        <cite>— Johny English, Travel Agent</cite>
    </div>
</section>
