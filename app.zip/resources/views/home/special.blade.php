<section class="special-section">
    <div class="container">
        <div class="section-heading text-center">
            <h5 class="dash-style">TRAVEL OFFER & DISCOUNT</h5>
            <h2>SPECIAL TRAVEL OFFER</h2>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="special-item">
                    <img src="{{ asset('assets/customer/images/img9.jpg') }}" alt="">
                    <h3><a href="#">Experience Glacier</a></h3>
                    <p>Now only $1200 (20% off)</p>
                </div>
            </div>
            <!-- Add more offers -->
        </div>
    </div>
</section>
