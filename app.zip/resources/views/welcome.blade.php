@extends('layouts.customer')

@section('content')

    @include('home.slider')
    <br>
    @include('home.packages')
@endsection
