@extends('layouts.customer')

@section('content')

    @include('home.slider')
    <br>
    @include('home.packages')
    @include('home.destination')
@endsection
